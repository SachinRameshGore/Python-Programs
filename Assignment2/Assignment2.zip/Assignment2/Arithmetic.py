print("Arthimetic  Module")


def Add(num1, num2):
    res = num1 + num2
    return res


def Sub(num1, num2):
    res = num1 - num2
    return res


def Mult(num1, num2):
    res = num1 * num2
    return res


def Div(num1, num2):
    res = num1 // num2
    return res
