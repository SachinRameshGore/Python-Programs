def Fun():
    print("Hello From Fun")

Fun()