def marvellous():
    for i in range(1, 6):
        print("Marvellous")


marvellous()
