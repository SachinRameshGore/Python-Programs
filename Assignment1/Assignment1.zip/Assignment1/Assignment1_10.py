name = "Marvellous"
print(len(name))