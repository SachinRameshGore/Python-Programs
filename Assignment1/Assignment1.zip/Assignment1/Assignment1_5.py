num = 10
while num != 0:
    print(num, end=" ")
    num = num - 1