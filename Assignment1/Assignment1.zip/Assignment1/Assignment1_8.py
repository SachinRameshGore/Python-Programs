def PrintStar(num):
    for i in range(1, num+1):
        print("*", end=" ")


n = int(input("Enter Number :"))
PrintStar(n)