def Add(num1, num2):
    res = num1 + num2
    return res


num1 = int(input("Enter First Number :"))
num2 = int(input("Enter Second Number :"))

add = Add(num1, num2)
print("Addition Is :", add)
