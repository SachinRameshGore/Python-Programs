from filterMapreduce import *;

def main():
    num = int(input("Enter How Many Elements You Want :"))
    rawData = Accept(num)
    print("Entered Numbers In array are :", rawData)
    filteredData = list(filter(checkPrime, rawData))
    print("Filter :", filteredData)
    if len(filteredData) > 0:
        modifiedData = list(map(multiply, filteredData))
        print("Map :", modifiedData)
        ans = reduce(Maximun, modifiedData)
        print("Reduce :", ans)
    else:
        print("There is No data Filtered out !!")


if __name__ == "__main__":
    main()