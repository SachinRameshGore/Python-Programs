from filterMapreduce import *;


def main():
    num = int(input("Enter How Many Elements You Want :"))
    rawData = Accept(num)
    print("Entered Numbers In array are :", rawData)
    filteredData = list(filter(checkNo, rawData))
    print("Filter :", filteredData)
    if len(filteredData) > 0:
        modifiedData = list(map(squre, filteredData))
        print("Map :", modifiedData)
        ans = reduce(addition, modifiedData)
        print("Reduce :", ans)
    else:
        print("There is No data Filtered out !!")


if __name__ == "__main__":
    main()